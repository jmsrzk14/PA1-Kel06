<!DOCTYPE html>
<html>
    <head>
        <title>Fruit Voting</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js>"></script>
    </head>
    <body>
		<div class="container">
			<br>
			<div class="row">
				<div class="col-sm-3 text-right">
					<img src="images/wiro.jpg" class="img-responsive" alt="Wiro">
				</div>
				<div class="col-sm-9 text-left">
					<h1>Uncle <b>Wiro</b> is looking for the best fruit.
					<br>Which one do you suggest?</h1><br>
				</div>
			</div>
			<div class="row text-center">
				<div class="col-sm-4">
					<img src="images/apple.jpg" class="img-responsive" alt="Apple">
					<br>
					<button type="submit" name="vote-fruit" value="apple" class="btn btn-success"><h2>Apple</h2></button>
					<br>
					<b>2 vote(s)</b>
				</div>
				<div class="col-sm-4">
					<img src="images/grape.jpg" class="img-responsive" alt="Grape">
					<br><button type="submit" name="vote-fruit" value="grape" class="btn btn-primary"><h2>Grape</h2></button>
					<br>
					<b>1 vote(s)</b>
				</div>
				<div class="col-sm-4">
					<img src="images/cheery.jpg" class="img-responsive" alt="Cheery">
					<br>
					<button type="submit" name="vote-fruit" value="cheery" class="btn btn-danger"><h2>Cheery</h2></button>
					<br>
					<img src="images/star.png" class="img-responsive" alt="Best" height="20px">&nbsp;
					<b>3 vote(s)</b>
				</div>
			</div>
			<br>
			<br>
			<div class="row text-center">
				<div class="col-sm-12">
					<h2>Your vote is meaningful for uncle <b>Wiro</b>.</h2>
				</div>
			</div>
		</div>
    </body>
</html>