/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 10.1.21-MariaDB : Database - fruitvoting
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
create database if not exists `fruitvoting`;

USE `fruitvoting`;

/*Table structure for table `vote` */

DROP TABLE IF EXISTS `vote`;

CREATE TABLE `vote` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `fruit` char(8) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `vvote` */

DROP TABLE IF EXISTS `vvote`;

/*!50001 DROP VIEW IF EXISTS `vvote` */;
/*!50001 DROP TABLE IF EXISTS `vvote` */;

/*!50001 CREATE TABLE  `vvote`(
 `fruit` char(8) ,
 `count` bigint(21) 
)*/;

/*View structure for view vvote */

/*!50001 DROP TABLE IF EXISTS `vvote` */;
/*!50001 DROP VIEW IF EXISTS `vvote` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vvote` AS (select `vote`.`fruit` AS `fruit`,count(`vote`.`fruit`) AS `count` from `vote` group by `vote`.`fruit` order by count(`vote`.`fruit`) desc) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
